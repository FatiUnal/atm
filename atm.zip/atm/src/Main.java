import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String Password, Username;
        int balance = 1500;
        int hak = 3;
        int select;

        while (hak > 0) {
            System.out.print("kullanıcı adınız: ");
            Username = input.next();
            System.out.print("sifre: ");
            Password = input.next();

            if (Username.equals("fatih") && Password.equals("123")) {
                System.out.println("başarıyla giriş yaptınız");

                do {
                    System.out.println("1- para yatırma \n2- para cekme \n3- bakiye sorgulama\n4- çıkış");
                    select = input.nextInt();
                    if (select == 1) {
                        System.out.println("lütfen miktarı girin: ");
                        int miktar = input.nextInt();
                        balance += miktar;
                        System.out.println("yeni bakiye "+ balance);
                    } else if (select == 2) {
                        System.out.println("lütfen miktarı girin: ");
                        int miktar = input.nextInt();
                        if (miktar > balance) {
                            System.out.println("paran yetmiyo");
                        } else {
                            balance -= miktar;
                            System.out.println("yeni bakiye "+ balance);
                        }

                    } else if (select == 3) {
                        System.out.println("bakiyeniz: " + balance);
                    }
                } while (select == 4) ; {
                    System.out.println("çıktın BB");
                    break;

                }
            } else {
                hak-- ;

             System.out.println(" başaramadın tekrar dene");
             System.out.println( hak + " hakkınız kalmıştır");
            }
            if ( hak == 0) {
                System.out.println(" Hesap gg olmuştur bankanıza danışınız");

            }

        }
    }
}
